package Super;



public class CajaException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CajaException(String msg) {
		
		super(msg);
	}
}
